export enum ApplicationStatus { // has customPipe and validates new status value and checks if its allowed
    OPEN = 'OPEN',
    IN_PROGRESS = 'IN_PROGRESS',
    CLOSED = 'CLOSED',
}